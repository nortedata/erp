<?php
namespace Eduardokum\LaravelBoleto\Api\Exception;

use Exception;

class CurlException extends Exception
{

}