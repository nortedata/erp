<?php
namespace Eduardokum\LaravelBoleto\Contracts\Cnab;

interface Cnab
{
}
