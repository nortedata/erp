<?php
namespace Eduardokum\LaravelBoleto\Contracts\Cnab;

interface Retorno extends Cnab
{
}
