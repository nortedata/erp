<?php
namespace Eduardokum\LaravelBoleto\Contracts\Cnab\Retorno\Cnab400;

use Eduardokum\LaravelBoleto\Contracts\Cnab\Retorno\Detalhe as DetalheBase;

interface Detalhe extends DetalheBase
{
}
